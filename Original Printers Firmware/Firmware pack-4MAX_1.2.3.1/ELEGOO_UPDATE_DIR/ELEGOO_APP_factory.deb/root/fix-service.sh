#! /bin/bash

UPDATE_PATH="/home/mks/gcode_files/sda1/ELEGOO_UPDATE_DIR"
while true
do
	if [ ! -e ${UPDATE_PATH}/fix_tag ];then
		if [ -f ${UPDATE_PATH}/ELEGOO_APP_FIX.deb ]
		then
			sleep 3
			if dpkg -i --force-overwrite ${UPDATE_PATH}/ELEGOO_APP_FIX.deb
			then
				touch ${UPDATE_PATH}/fix_app_successed
				echo "fix app successed"
			else
				touch ${UPDATE_PATH}/fix_app_failed
				echo "fix app failed"
			fi
		fi

		if [ -f ${UPDATE_PATH}/ELEGOO_FIX_BAG.deb ]
		then
			sleep 3
			if dpkg -i --force-overwrite ${UPDATE_PATH}/ELEGOO_FIX_BAG.deb
			then
				touch ${UPDATE_PATH}/fix_klipper_successed
				touch ${UPDATE_PATH}/fix_tag
				echo "fix klipper successed"
				sync
				reboot
			else
				touch ${UPDATE_PATH}/fix_klipper_failed
				echo "fix klipper failed"
			fi
		fi
	fi
	sleep 5
done
